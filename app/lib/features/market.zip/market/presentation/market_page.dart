import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:wts/core/router/nav_collapse.dart';
import 'package:wts/features/market/presentation/market_filter_sheet.dart';
import 'package:wts/features/market/presentation/market_providers.dart';
import 'package:wts/features/market/presentation/market_style.dart';
import 'package:wts/features/market/presentation/product_card.dart';
import 'package:wts/shared/widgets/common_widgets.dart';

/// Urutan chip kategori di beranda Market (sesuai desain).
const _kChipOrder = <String>[
  'IoT',
  'Buku',
  'Elektronik',
  'Kos',
  'Perabot',
  'Jasa',
  'Lainnya',
];

/// Scroll melewati ambang ini -> navigasi menyusut & header jadi pil melayang.
const double _kCollapseAt = 150;
const double _kExpandAt = 60;

class MarketPage extends ConsumerStatefulWidget {
  const MarketPage({super.key});

  @override
  ConsumerState<MarketPage> createState() => _MarketPageState();
}

class _MarketPageState extends ConsumerState<MarketPage> {
  final _scroll = ScrollController();
  bool _collapsed = false;

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  bool _onScroll(ScrollNotification n) {
    if (n.depth != 0 || n.metrics.axis != Axis.vertical) return false;
    final y = n.metrics.pixels;
    final next = _collapsed ? y > _kExpandAt : y > _kCollapseAt;
    if (next != _collapsed) {
      setState(() => _collapsed = next);
      ref.read(navCollapsedProvider.notifier).set(next);
    }
    return false;
  }

  void _openSearch() => context.push('/market/search');
  void _openFavorites() => context.push('/market/favorites');
  void _openTransactions() => context.push('/market/transactions');
  void _openFilter() => showMarketFilterSheet(context, marketFilterProvider);

  @override
  Widget build(BuildContext context) {
    final filter = ref.watch(marketFilterProvider);
    final products = ref.watch(visibleProductsProvider);
    final top = MediaQuery.paddingOf(context).top;
    final bottom = MediaQuery.paddingOf(context).bottom;

    // FAB "+" : di atas kapsul saat penuh, sejajar lingkaran saat menyusut.
    final fabBottom = _collapsed
        ? navCircleBottom(context)
        : navBottomGap(context) + kNavHeight + 24;

    return Scaffold(
      backgroundColor: MC.bg,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          NotificationListener<ScrollNotification>(
            onNotification: _onScroll,
            child: RefreshIndicator(
              edgeOffset: top,
              onRefresh: () async {
                ref.invalidate(productsProvider);
                await ref.read(productsProvider.future);
              },
              child: CustomScrollView(
                controller: _scroll,
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  SliverToBoxAdapter(
                    child: _Header(
                      top: top,
                      filterCount: filter.activeCount,
                      category: filter.category,
                      onSearch: _openSearch,
                      onFilter: _openFilter,
                      onFavorites: _openFavorites,
                      onTransactions: _openTransactions,
                      onCategory: (c) => ref
                          .read(marketFilterProvider.notifier)
                          .setCategory(c),
                    ),
                  ),
                  products.when(
                    loading: () => SliverPadding(
                      padding: EdgeInsets.fromLTRB(20, 20, 20, 140 + bottom),
                      sliver: _grid(
                        count: 6,
                        builder: (_, _) => const SkeletonBox(radius: 16),
                      ),
                    ),
                    error: (e, _) => SliverFillRemaining(
                      hasScrollBody: false,
                      child: ErrorState(
                        onRetry: () => ref.invalidate(productsProvider),
                      ),
                    ),
                    data: (list) {
                      if (list.isEmpty) {
                        return const SliverFillRemaining(
                          hasScrollBody: false,
                          child: EmptyState(
                            icon: Icons.search_off_rounded,
                            title: 'Belum ada barang',
                            message:
                                'Coba ubah filter, atau jadilah yang pertama memposting.',
                          ),
                        );
                      }
                      return SliverMainAxisGroup(
                        slivers: [
                          SliverToBoxAdapter(
                            child: _CountRow(
                              count: list.length,
                              sort: filter.sort,
                              onSort: (s) => ref
                                  .read(marketFilterProvider.notifier)
                                  .setSort(s),
                            ),
                          ),
                          SliverPadding(
                            padding:
                                EdgeInsets.fromLTRB(20, 4, 20, 150 + bottom),
                            sliver: _grid(
                              count: list.length,
                              builder: (context, i) => ProductCard(
                                product: list[i],
                                onTap: () => context
                                    .push('/market/product/${list[i].id}'),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ),

          // Pil melayang (pengganti header) saat di-scroll.
          Positioned(
            right: 14,
            top: top + 40,
            child: IgnorePointer(
              ignoring: !_collapsed,
              child: AnimatedSlide(
                duration: const Duration(milliseconds: 320),
                curve: Curves.easeOutCubic,
                offset: _collapsed ? Offset.zero : const Offset(1.4, 0),
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 220),
                  opacity: _collapsed ? 1 : 0,
                  child: _FloatingPill(
                    filterActive: filter.activeCount > 0,
                    onSearch: _openSearch,
                    onFilter: _openFilter,
                    onFavorites: _openFavorites,
                    onTransactions: _openTransactions,
                  ),
                ),
              ),
            ),
          ),

          // Tombol "+".
          AnimatedPositioned(
            duration: const Duration(milliseconds: 380),
            curve: Curves.easeInOutCubic,
            right: _collapsed ? 25 : 20,
            bottom: fabBottom,
            child: _AddFab(onTap: () => context.push('/market/new')),
          ),
        ],
      ),
    );
  }

  SliverGrid _grid({
    required int count,
    required Widget Function(BuildContext, int) builder,
  }) {
    return SliverGrid(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        mainAxisExtent: kCardExtentPlain,
      ),
      delegate: SliverChildBuilderDelegate(builder, childCount: count),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.top,
    required this.filterCount,
    required this.category,
    required this.onSearch,
    required this.onFilter,
    required this.onFavorites,
    required this.onTransactions,
    required this.onCategory,
  });

  final double top;
  final int filterCount;
  final String? category;
  final VoidCallback onSearch;
  final VoidCallback onFilter;
  final VoidCallback onFavorites;
  final VoidCallback onTransactions;
  final ValueChanged<String?> onCategory;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const Positioned.fill(child: WarmGlow()),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: top + 18),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Row(
                children: [
                  const WtsLogoMark(size: 42),
                  const SizedBox(width: 8),
                  Text(
                    'WTS Market',
                    style: mt(
                      size: 18,
                      weight: FontWeight.w800,
                      color: MC.orange,
                    ),
                  ),
                  const Spacer(),
                  RoundIconButton(
                    icon: Icons.favorite_border_rounded,
                    size: 44,
                    onTap: onFavorites,
                    tooltip: 'Favorit',
                  ),
                  const SizedBox(width: 12),
                  RoundIconButton(
                    icon: Icons.shopping_bag_outlined,
                    size: 44,
                    onTap: onTransactions,
                    tooltip: 'Transaksi saya',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: 'Cari apa\n',
                      style: mt(
                        size: 32,
                        weight: FontWeight.w800,
                        color: MC.ink,
                        height: 1.15,
                      ),
                    ),
                    TextSpan(
                      text: 'hari ini?',
                      style: mt(
                        size: 32,
                        weight: FontWeight.w800,
                        color: MC.orange,
                        height: 1.15,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Barang kuliah, kos, sampai jasa dari sesama\nmahasiswa Nusa Putra.',
                style: mt(
                  size: 14,
                  weight: FontWeight.w500,
                  color: MC.slate,
                  height: 1.45,
                ),
              ),
            ),
            const SizedBox(height: 22),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 26),
              child: Row(
                children: [
                  Expanded(child: _SearchBox(onTap: onSearch)),
                  const SizedBox(width: 14),
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      RoundIconButton(
                        icon: Icons.filter_alt_outlined,
                        size: 52,
                        iconSize: 24,
                        onTap: onFilter,
                        tooltip: 'Filter',
                      ),
                      if (filterCount > 0)
                        Positioned(
                          right: 2,
                          top: 2,
                          child: Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: MC.orange,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 2),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 24),
                children: [
                  _CategoryChip(
                    label: 'Semua',
                    selected: category == null,
                    onTap: () => onCategory(null),
                  ),
                  for (final c in _kChipOrder) ...[
                    const SizedBox(width: 10),
                    _CategoryChip(
                      label: c,
                      selected: category == c,
                      onTap: () => onCategory(category == c ? null : c),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ],
    );
  }
}

class _SearchBox extends StatelessWidget {
  const _SearchBox({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .92),
        borderRadius: BorderRadius.circular(26),
        boxShadow: softShadow(.10, 16),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: BorderRadius.circular(26),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Row(
              children: [
                const Icon(Icons.search_rounded, size: 22, color: MC.slate),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Cari buku, gawai, catatan kuliah',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: mt(
                      size: 14,
                      weight: FontWeight.w500,
                      color: MC.slateLight,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  const _CategoryChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.symmetric(horizontal: 20),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: selected ? MC.blue : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? MC.blue : MC.line),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: MC.blue.withValues(alpha: .28),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Text(
          label,
          style: mt(
            size: 14,
            weight: selected ? FontWeight.w700 : FontWeight.w600,
            color: selected ? Colors.white : MC.text,
          ),
        ),
      ),
    );
  }
}

class _CountRow extends StatelessWidget {
  const _CountRow({
    required this.count,
    required this.sort,
    required this.onSort,
  });

  final int count;
  final MarketSort sort;
  final ValueChanged<MarketSort> onSort;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(30, 6, 24, 10),
      child: Row(
        children: [
          Text(
            '$count barang',
            style: mt(size: 13, weight: FontWeight.w500, color: MC.slate),
          ),
          const Spacer(),
          PopupMenuButton<MarketSort>(
            onSelected: onSort,
            position: PopupMenuPosition.under,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            color: Colors.white,
            itemBuilder: (_) => [
              for (final s in MarketSort.values)
                PopupMenuItem(
                  value: s,
                  child: Text(
                    s.label,
                    style: mt(
                      size: 14,
                      weight: s == sort ? FontWeight.w700 : FontWeight.w500,
                      color: s == sort ? MC.blue : MC.text,
                    ),
                  ),
                ),
            ],
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  sort.label,
                  style: mt(size: 13, weight: FontWeight.w600, color: MC.ink),
                ),
                const SizedBox(width: 2),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  size: 20,
                  color: MC.ink,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Pil vertikal: cari, filter, favorit, transaksi (muncul saat di-scroll).
class _FloatingPill extends StatelessWidget {
  const _FloatingPill({
    required this.filterActive,
    required this.onSearch,
    required this.onFilter,
    required this.onFavorites,
    required this.onTransactions,
  });

  final bool filterActive;
  final VoidCallback onSearch;
  final VoidCallback onFilter;
  final VoidCallback onFavorites;
  final VoidCallback onTransactions;

  @override
  Widget build(BuildContext context) {
    Widget item(IconData icon, VoidCallback onTap, {bool dot = false}) {
      return InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: SizedBox(
          width: 48,
          height: 46,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Icon(icon, size: 22, color: MC.ink),
              if (dot)
                Positioned(
                  right: 11,
                  top: 9,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: MC.orange,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    }

    Widget divider() => Container(
          width: 22,
          height: 1,
          color: MC.orange.withValues(alpha: .18),
        );

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(
        color: MC.peachButton.withValues(alpha: .97),
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: Colors.white),
        boxShadow: softShadow(.14, 18),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            item(Icons.search_rounded, onSearch),
            divider(),
            item(Icons.filter_alt_outlined, onFilter, dot: filterActive),
            divider(),
            item(Icons.favorite_border_rounded, onFavorites),
            divider(),
            item(Icons.shopping_bag_outlined, onTransactions),
          ],
        ),
      ),
    );
  }
}

class _AddFab extends StatelessWidget {
  const _AddFab({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: MC.blue,
        boxShadow: [
          BoxShadow(
            color: MC.blue.withValues(alpha: .42),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        type: MaterialType.transparency,
        shape: const CircleBorder(),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: const Icon(Icons.add_rounded, size: 30, color: Colors.white),
        ),
      ),
    );
  }
}